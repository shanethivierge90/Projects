package com.example.assignment3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.assignment3.R;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ImageView appetizersImage;
    private ImageView mealsImage;
    private ImageView sodasImage;
    private ImageView dessertsImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        appetizersImage = findViewById(R.id.pizza);
        mealsImage = findViewById(R.id.meals);
        sodasImage = findViewById(R.id.sodas);
        dessertsImage = findViewById(R.id.desserts);

        appetizersImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFoodListActivity("Appetizers");
            }
        });
        mealsImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFoodListActivity("Meals");
            }
        });
        sodasImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFoodListActivity("Sodas");
            }
        });
        dessertsImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFoodListActivity("Desserts");
            }
        });
    }

    private void openFoodListActivity(String category) {

        Intent intent = new Intent(MainActivity.this, FoodListActivity.class);
        intent.putExtra("category", category);

        startActivity(intent);
    }
}