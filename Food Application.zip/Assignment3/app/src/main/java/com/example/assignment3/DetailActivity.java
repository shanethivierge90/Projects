package com.example.assignment3;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class DetailActivity extends AppCompatActivity {

    private ImageView foodImage;
    private TextView foodName;
    private EditText foodQuantity;
    private TextView priceText;
    private Button button;
    private Map<String, Integer> foodImageMap;
    private Map<String, String> foodInformationMap;
    private Map<String, String> foodPriceMap;
    private TextView descriptionDescriptin;
    public static final String PREFS_NAME = "MyPrefs";
    public static final String PREF_SELECTED_ITEMS = "SelectedItems";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        foodImage = findViewById(R.id.foodImage);
        foodName = findViewById(R.id.foodName);
        foodQuantity = findViewById(R.id.foodQuantity);
        priceText = findViewById(R.id.price);
        button = findViewById(R.id.button);
        descriptionDescriptin = findViewById(R.id.descriptionDescriptin);

        foodInformationMap = initializeFoodInformation();
        foodPriceMap = initializeFoodPrices();
        foodImageMap = initializeFoodImages();

        String itemSelected = getIntent().getStringExtra("itemSelected");
        if (itemSelected != null) {
            foodInformation(itemSelected);
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToCart(itemSelected);
            }
        });
    }

    private void foodInformation(String itemSelected) {
        foodName.setText(itemSelected);
        descriptionDescriptin.setText(foodInformationMap.get(itemSelected));
        priceText.setText(foodPriceMap.get(itemSelected));
        foodImage.setImageResource(foodImageMap.get(itemSelected));
    }

    private Map<String, Integer> initializeFoodImages() {
        Map<String, Integer> map = new HashMap<>();
        map.put("Pizzas", R.drawable.smallp);
        map.put("Wings", R.drawable.chicken_wings);
        map.put("Soup", R.drawable.tomato_soup);
        map.put("Chicken", R.drawable.meals);
        map.put("Burger", R.drawable.burger2);
        map.put("Salad", R.drawable.csalad);
        map.put("Coke", R.drawable.coke);
        map.put("Sprite", R.drawable.sprite);
        map.put("Crush", R.drawable.ocrush);
        map.put("Sorbet", R.drawable.icecream);
        map.put("Brownie", R.drawable.brownies);
        map.put("Cake", R.drawable.ccake);
        return map;


    }

    private Map<String, String> initializeFoodInformation() {
        Map<String, String> map = new HashMap<>();
        map.put("Pizzas", "Small pizzas with a variety of toppings on them.");
        map.put("Wings", "Your choice of barbecue, medium or extremely hot chicken wings.");
        map.put("Soup", "A chef's special: Freshly served tomato soup.");
        map.put("Chicken", "A chicken dish with a side of rice or mashed potatoes.");
        map.put("Burger", "Burgers served with your choice of toppings and along with french fries on the side.");
        map.put("Salad", "Freshly made cesar salad that contains tomatoes, cucumber, lettuce and your choice of salad dressing.");
        map.put("Coke", "A classic soda: Coke served regular or diet.");
        map.put("Sprite", "Another classic soda: Sprite, which is also served regular or diet.");
        map.put("Crush", "The owner's favorite soda: Orange Crush, which, of course, always has an orange flavour.");
        map.put("Sorbet", "Sorbet with your choice of toppings on it, which includes chocolate sauce.");
        map.put("Brownie", "Freshly cooked brownies served directly from the oven.");
        map.put("Cake", "Many of our cakes, including cheese cakes, are always freshly made rich with cheese.");
        return map;


    }

    private Map<String, String> initializeFoodPrices() {
        Map<String, String> map = new HashMap<>();
        map.put("Pizzas", "$4.00");
        map.put("Wings", "$6.00");
        map.put("Soup", "$3.00");
        map.put("Chicken", "$6.00");
        map.put("Burger", "$8.00");
        map.put("Salad", "$5.00");
        map.put("Coke", "$1.75");
        map.put("Sprite", "$2.00");
        map.put("Crush", "$3.00");
        map.put("Sorbet", "$6.00");
        map.put("Brownie", "$8.00");
        map.put("Cake", "$9.00");
        return map;


    }

    private void addToCart(String itemSelected) {
        String unitPrice1 = foodQuantity.getText().toString().trim();
        if (unitPrice1.isEmpty()) {
            Toast.makeText(DetailActivity.this, "Please enter quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(unitPrice1);
        String unitPriceString = foodPriceMap.get(itemSelected);
        if (unitPriceString == null) {
            Toast.makeText(DetailActivity.this, "Item price not found", Toast.LENGTH_SHORT).show();
            return;
        }

        double unitPrice2 = Double.parseDouble(unitPriceString.substring(1));

        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        Set<String> cartItemsSet = preferences.getStringSet(PREF_SELECTED_ITEMS, new HashSet<>());

        boolean itemAlreadyThere = false;
        for (String cartItem : cartItemsSet) {
            String[] sections = cartItem.split(" ");
            if (sections.length >= 3 && sections[0].equals(itemSelected)) {
                int itemQuantity = Integer.parseInt(sections[1]);
                double existingPrice = Double.parseDouble(sections[2].substring(1));
                int newQuantity = itemQuantity + quantity;
                double nPrice = existingPrice + (quantity * unitPrice2);
                String itemUpdated = String.format("%s %d $%.2f", itemSelected, newQuantity, nPrice);
                cartItemsSet.remove(cartItem); // Remove old item
                cartItemsSet.add(itemUpdated); // Add updated item
                itemAlreadyThere = true;
                break;
            }
        }
        if (!itemAlreadyThere) {
            double totalPrice = quantity * unitPrice2;
            String cartItem = String.format("%s %d $%.2f", itemSelected, quantity, totalPrice);
            cartItemsSet.add(cartItem);
        }

        editor.putStringSet(PREF_SELECTED_ITEMS, cartItemsSet);
        editor.apply();

        Toast.makeText(DetailActivity.this, itemSelected + " (" + quantity + ") added to cart", Toast.LENGTH_SHORT).show();
    }
}
