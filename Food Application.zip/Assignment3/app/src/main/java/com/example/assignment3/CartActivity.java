package com.example.assignment3;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CartActivity extends AppCompatActivity {

    private ListView cartListView;
    private TextView totalAccum2;
    private Button clearButton;
    private ArrayList<CartItem> cartItemsList;

    public static final String PREF_SELECTED_ITEMS = "SelectedItems";
    public static final String PREFS_NAME = "MyPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        cartListView = findViewById(R.id.cartListView);
        totalAccum2 = findViewById(R.id.totalAccum2);
        clearButton = findViewById(R.id.clearButton);

        cartItemsList = new ArrayList<>();
        ArrayAdapter<CartItem> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cartItemsList);
        cartListView.setAdapter(adapter);

        loadCartItems();

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearCart();
                updateTotalPriceInFoodActivity(0.0);
            }
        });
    }

    private void loadCartItems() {
        ArrayList<String> cartItems = getCartItemsFromPrefs();

        cartItemsList.clear();
        double totalPrice = 0.0;

        for (String cartItem : cartItems) {
            String[] sections = cartItem.split(" ");
            if (sections.length >= 2) {
                String itemName = sections[0];
                int quantity = 0;
                if (!TextUtils.isEmpty(sections[1])) {
                    quantity = Integer.parseInt(sections[1]);
                }
                double originalPrice = getOriginalPrice(itemName);
                double itemTotal = quantity * originalPrice;
                totalPrice += itemTotal;

                // Add cart item to list
                cartItemsList.add(new CartItem(itemName, quantity, originalPrice, itemTotal));
            }
        }

        // Update total price TextView
        String formattedTotalPrice = String.format("Total: $%.2f", totalPrice);
        totalAccum2.setText(formattedTotalPrice);
        updateTotalPriceInFoodActivity(totalPrice);

        // Notify the adapter that data set has changed
        ArrayAdapter<CartItem> adapter = (ArrayAdapter<CartItem>) cartListView.getAdapter();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    private ArrayList<String> getCartItemsFromPrefs() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return new ArrayList<>(preferences.getStringSet(PREF_SELECTED_ITEMS, new HashSet<>()));
    }


    private double getOriginalPrice(String itemName) {
        switch (itemName) {
            case "Pizzas":
                return 4.00;
            case "Wings":
                return 6.00;
            case "Soup":
                return 3.00;
            case "Chicken":
                return 6.00;
            case "Burger":
                return 8.00;
            case "Salad":
                return 5.00;
            case "Coke":
                return 1.75;
            case "Sprite":
                return 2.00;
            case "Crush":
                return 3.00;
            case "Sorbet":
                return 6.00;
            case "Brownie":
                return 8.00;
            case "Cake":
                return 9.00;
            default:
                return 0.00;


        }
    }

    private void clearCart() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.remove(PREF_SELECTED_ITEMS);
        editor.apply();

        cartItemsList.clear();
        ArrayAdapter<CartItem> adapter = (ArrayAdapter<CartItem>) cartListView.getAdapter();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }

        totalAccum2.setText("Total: $0.00");
        Toast.makeText(this, "Cart cleared", Toast.LENGTH_SHORT).show();
    }

    private void updateTotalPriceInFoodActivity(double totalPrice) {
        SharedPreferences preferences = getSharedPreferences(FoodListActivity.PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putFloat(FoodListActivity.PREF_TOTAL_PRICE, (float) totalPrice);
        editor.apply();
    }

    // Inner class representing a cart item
    public static class CartItem {
        private String name;
        private int quantity;
        private double price;
        private double totalPrice;

        public CartItem(String name, int quantity, double price, double totalPrice) {
            this.name = name;
            this.quantity = quantity;
            this.price = price;
            this.totalPrice = totalPrice;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }

        public double getPrice() {
            return price;
        }

        public double getTotalPrice() {
            return totalPrice;
        }

        @Override
        public String toString() {
            // Adjust formatting based on the item name
            if (name.equals("Pizzas")) { //6
                return String.format("%-15s %4d %16.2f %15.2f", name, quantity, price, totalPrice);
            } else if (name.equals("Wings")) { //5
                return String.format("%-15s %5d %16.2f %14.2f", name, quantity, price, totalPrice);
            } else if (name.equals("Soup")) {
                return String.format("%-15s %6d %17.2f %14.2f", name, quantity, price, totalPrice);
            } else if (name.equals("Chicken")) { //6
                return String.format("%-12s %7d %15.2f %14.2f", name, quantity, price, totalPrice);
            } else if (name.equals("Burger")) { //5
                return String.format("%-15s %5d %16.2f %14.2f", name, quantity, price, totalPrice);
            } else if (name.equals("Salad")) {
                return String.format("%-15s %5d %16.2f %15.2f", name, quantity, price, totalPrice);
            } else if (name.equals("Coke")) { //6
                return String.format("%-15s %6d %15.2f %15.2f", name, quantity, price, totalPrice);
            } else if (name.equals("Sprite")) { //5
                return String.format("%-15s %7d %15.2f %15.2f", name, quantity, price, totalPrice);
            } else if (name.equals("Crush")) {
                return String.format("%-15s %5d %16.2f %15.2f", name, quantity, price, totalPrice);
            }
            else if (name.equals("Sorbet")) {
                return String.format("%-15s %5d %16.2f %14.2f", name, quantity, price, totalPrice);
            }else if (name.equals("Brownie")) {
                return String.format("%-15s %4d %15.2f %15.2f", name, quantity, price, totalPrice);
            }else if (name.equals("Cake")) {
                return String.format("%-15s %5d %16.2f %15.2f", name, quantity, price, totalPrice);
            }


            // Add more conditions as needed for other food items
            else {
                return String.format("%-15s %3d %18.2f %10.2f", name, quantity, price, totalPrice);
            }
        }
    }
}
