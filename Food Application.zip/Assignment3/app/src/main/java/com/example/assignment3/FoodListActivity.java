package com.example.assignment3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FoodListActivity extends AppCompatActivity {

    // Constants for shared preferences keys
    public static final String PREFS_NAME = "MyPrefs";
    public static final String PREF_SELECTED_ITEMS = "ItemsSelected";
    public static final String PREF_TOTAL_PRICE = "TotalPrice";

    private ListView foodListView;
    private Button cartButton;
    private TextView totalPriceTextView;

    private Set<String> selectedItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list);

        foodListView = findViewById(R.id.foodListView);
        totalPriceTextView = findViewById(R.id.totalAccum); // Ensure this matches your XML
        cartButton = findViewById(R.id.cartButton);

        String category = getIntent().getStringExtra("category");
        List<String> foodItems = createFoodItems(category);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, foodItems);
        foodListView.setAdapter(adapter);

        selectedItems = getSelectedItemsFromPrefs();

        foodListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String itemSelected = foodItems.get(position);
                openDetailActivity(itemSelected);
            }
        });

        cartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCartActivity();
            }
        });

        updateTotalPrice(); // Update total price display onResume
    }

    private List<String> createFoodItems(String category) {
        List<String> items = new ArrayList<>();

        switch (category) {
            case "Appetizers":
                items.add("Pizzas");
                items.add("Wings");
                items.add("Soup");
                break;
            case "Meals":
                items.add("Chicken");
                items.add("Burger");
                items.add("Salad");
                break;
            case "Sodas":
                items.add("Coke");
                items.add("Sprite");
                items.add("Crush");
                break;
            case "Desserts":
                items.add("Sorbet");
                items.add("Brownie");
                items.add("Cake");
                break;
            default:
                break;
        }
        return items;
    }

    private void openDetailActivity(String itemSelected) {
        Intent intent = new Intent(FoodListActivity.this, DetailActivity.class);
        intent.putExtra("itemSelected", itemSelected);
        startActivity(intent);
    }

    private void openCartActivity() {
        Intent intent = new Intent(FoodListActivity.this, CartActivity.class);
        startActivity(intent);
    }

    private Set<String> getSelectedItemsFromPrefs() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return preferences.getStringSet(PREF_SELECTED_ITEMS, new HashSet<>());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateTotalPrice(); // Update total price when activity resumes
    }

    private void updateTotalPrice() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        float totalPriceFloat = preferences.getFloat(PREF_TOTAL_PRICE, 0.0f); // Get total price from shared preferences
        totalPriceTextView.setText("Total: $" + String.format("%.2f", totalPriceFloat));
    }
}
