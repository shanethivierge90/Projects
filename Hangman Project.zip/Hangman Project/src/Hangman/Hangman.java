package Hangman;

import java.util.Scanner;

public class Hangman {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		//Simple introduction like in the instructions.
		System.out.println("------------------");
		System.out.println("WELCOME TO HANGMAN");
		System.out.println("------------------");
		System.out.println("\n"); //Will add a space each time this appears.
		System.out.println("OK Guessing Player ... turn around, while your friend enters the word to guess!");

		// This section will allow the player to enter a word.
		System.out.print("Enter your word (up to 10 letters only, not case sensitive: ");
		String hangmanWord = input.next().toLowerCase();
		
		// This will turn the word into an integer.
		int newHangmanWord = hangmanWord.length();
		
		// To let the users know to switch players.
		System.out.print("Great! Now switch to the other player.");

		//This will add 20 spaces.
		System.out.println("\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n");		
				
		//The amount  of guesses to subtract by each time.
		int guesses = 10;
       
		//This will change the word into "*" regardless of how long the word is.
		String asterisk = "*".repeat(newHangmanWord);
        String letters = "abcdefghijklmnopqrstuvwxyz";
		
		// This whole loop will run as long as there is more than zero guesses.
		while (guesses > 0) {
			// Keeps track of the guesses.
			System.out.println(asterisk + " is the current word to date. " + guesses + " guess(es) left");
			// Lets user input between yes or no.
			System.out.print("Want to solve the puzzle? Enter \"Y\" to solve the puzzle, or \"N\" to guess a character: ");
			String yesNo = input.next();
			
				// If the user chooses yes(y) in lower case or upper case.
				if (yesNo.equals("Y") || yesNo.equals("y")){
					// The user guesses the word.
					System.out.print("What do you think the word is? ");
					String guessedWord = input.next();
					
					// If the user gets the word correct.
					if (guessedWord.equals(hangmanWord)) {
						System.out.println("------------------------------------------------------------------------------------------------------");
						System.out.println("Congratulations!!!");
						System.out.println("You guessed the mystery word \"" + hangmanWord + "\" in " + (guesses-1) + " guess(es)!");
						System.out.println("\n");
						System.out.println("Goodbye....");
						System.out.println("------------------------------------------------------------------------------------------------------");
						break; // Breaks the loop.
					
					// If the user does not get the word correct.
					} else {
						System.out.println("Incorrect...You lose a guess");
						System.out.println("\n");
						guesses--; //Will subtract the guesses each time this appears.
					}	
				// If the user chooses no(n) in lower case or upper case.	
				} else if (yesNo.equals("N") || yesNo.equals("n")){
					// Shows list of letters and then the user can input a letter..
					System.out.print("Here are the letters you can choose from. Please choose one: " + letters + " ");
					String guessedLetter = input.next().toLowerCase();
					System.out.println("\n");
					
					// If user chooses a number, it will not work and they lose a guess.
					if (guessedLetter.equals("0") || guessedLetter.equals("1") || guessedLetter.equals("2") || guessedLetter.equals("3") || guessedLetter.equals("4") || guessedLetter.equals("5") || guessedLetter.equals("6") || guessedLetter.equals("7") || guessedLetter.equals("8") || guessedLetter.equals("9")){
						System.out.println("Sorry, no numbers allowed!");
						System.out.println("\n");
						guesses--;
										
					// If the user inputs more than one character and they will lose a guess.
					} else if (guessedLetter.length() != 1) {
						System.out.println("Sorry, needs to be no more than one character long. Haven't you played Hangman before?");
						// Just trying to have fun here.
						System.out.println("You know what...for that you are losing a guess!");
						System.out.println("\n");
						guesses--;
									
					} else {
							// Created a new variable that has nothing in it.
		                    String newCurrentWord = "";
		                    // For loop to change the '*" into a letter.
		                    for (int ii = 0; ii < hangmanWord.length(); ii++) 
		                        if (hangmanWord.charAt(ii) == guessedLetter.charAt(0) ) {
		                            newCurrentWord += guessedLetter;
		                        } else {
		                            newCurrentWord += asterisk.charAt(ii);
		                        }
		                    // Will return the newCurrentWord back to the asterisk variable.
		                    asterisk = newCurrentWord;
		                    guesses--;
					}
				
				// Final else statement in the loop.
				} else {
					guesses--;
					continue;
				}
					
				// If there are no more guesses, it is game over for the user.						
				if (guesses <= 0) {
					System.out.println("---------------------------------------");
					System.out.println("Sorry, you did not guess the mystery word \"" + hangmanWord + "\"");
					System.out.println("\n");
					System.out.println("Goodbye....");
					System.out.println("---------------------------------------");
					break;
				}
		
				// If the user finds each letter in the word before the amount of guesses run out.
				if (asterisk.equals(hangmanWord)) {
					System.out.println("-------------------------------");
					System.out.println("Congradulations!");
					System.out.println("You guessed the mystery word \"" + hangmanWord + "\" in " + guesses + " guess(es)");
					System.out.println("\n");
					System.out.println("Goodbye....");
					System.out.println("-------------------------------");
					break;
			}       			
		}			
	}	
}
	