package com.example.assignment2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    EditText height1;
    EditText weight1;
    TextView resultBmi;
    SharedPreferences preferencesBmi;

    ImageView mainButton;

    public static final String HEIGHT_KEY = "height_key";
    public static final String WEIGHT_KEY = "weight_key";
    public static final String PREFS_NAME = "BMI_Calculator";
    public static final String BACKGROUND_KEY = "background_key";
    private TextView Result;
    public static final String BMI = "BMI";

    public static final String BMI1 = "BMI1";


    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        height1 = findViewById(R.id.height1);
        weight1 = findViewById(R.id.weight1);
        resultBmi = findViewById(R.id.resultBmi);
        preferencesBmi = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mainButton = findViewById(R.id.mainButton);

        if (savedInstanceState != null) {
            String saveHeight = savedInstanceState.getString(HEIGHT_KEY);
            String saveWeight = savedInstanceState.getString(WEIGHT_KEY);
            height1.setText(saveHeight);
            weight1.setText(saveWeight);

        }

        //Loads on restart.
        String savedBmi = preferencesBmi.getString(BMI, null);
        String savedbmiCategory = preferencesBmi.getString(BMI1, null);
        if (savedBmi != null && savedbmiCategory != null){
            resultBmi.setText(String.format("BMI: %2s (%s)", savedBmi, savedbmiCategory));
        }

        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String height = height1.getText().toString();
                String weight = weight1.getText().toString();
                if (!height.isEmpty() && !weight.isEmpty()) {
                    float height2 = Float.parseFloat(height);
                    float weight2 = Float.parseFloat(weight);

                    float officialBmi = weight2 / (height2 * height2);
                    String bmiCategory = getBmiCategory(officialBmi);

                    String bmiText = String.format("%.2f", officialBmi);
                    resultBmi.setText(String.format("BMI: %.2f (%s)", officialBmi, bmiCategory));

               SharedPreferences.Editor editor = preferencesBmi.edit();
               editor.putString(BMI, bmiText);
               editor.putString(BMI1, bmiCategory);
               editor.apply();
                } else {
                    resultBmi.setText("Please enter valid numbers");
                }
            }
        });
        mainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });

        applyBackground(preferencesBmi.getInt(BACKGROUND_KEY, 0));

    }

    @Override
    protected void onResume() {
        super.onResume();
        int selectedBackground = preferencesBmi.getInt(BACKGROUND_KEY, 0);
        Log.d("MainActivity", "Selected Background: " + selectedBackground);

        applyBackground(selectedBackground);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(HEIGHT_KEY, height1.getText().toString());
        outState.putString(WEIGHT_KEY, weight1.getText().toString());

    }


    private String getBmiCategory(float bmi) {
        String bmiCategory;
        if (bmi < 18.50) {
            bmiCategory = "Underweight";
        } else if (bmi >= 18.50 && bmi <= 24.99) {
            bmiCategory = "Normal";
        } else if (bmi >= 25 && bmi <= 29.99) {
            bmiCategory = "Overweight";
        } else if (bmi >= 30 && bmi <= 39.99) {
            bmiCategory = "Obese";
        } else {
            bmiCategory = "Morbidly Obese";
        }
        return bmiCategory;
    }

    private void applyBackground(int position) {
        int backgroundId;
        switch (position) {
            case 1:
                backgroundId = R.drawable.dyellow;
                break;
            case 2:
                backgroundId = R.drawable.red;
                break;
            default:
                backgroundId = R.drawable.dgreen;


        }
        findViewById(R.id.main).setBackgroundResource(backgroundId);
    }
}
