package com.example.assignment2;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    Spinner spinner;
    SharedPreferences preferencesBmi;

    public static final String PREFS_NAME = "BMI_Calculator";
    public static final String BACKGROUND_KEY = "background_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferencesBmi = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setContentView(R.layout.activity_main2_landscape);
        } else {
            setContentView(R.layout.activity_main2_landscape);
        }

        spinner = findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.background_array, android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        int savedBackground = preferencesBmi.getInt(BACKGROUND_KEY, 0);
        if (savedBackground < 0 || savedBackground >= adapter.getCount()) {
            savedBackground = 0;
            SharedPreferences.Editor editor = preferencesBmi.edit();
            editor.putInt(BACKGROUND_KEY, savedBackground);
            editor.apply();
        }
        spinner.setSelection(savedBackground);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SharedPreferences.Editor editor = preferencesBmi.edit();
                editor.putInt(BACKGROUND_KEY, position);
                editor.apply();
                applyBackground(position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void applyBackground(int position) {
        int backgroundId;
        switch (position) {
            case 1:
                backgroundId = R.drawable.dyellow;
                break;
            case 2:
                backgroundId = R.drawable.red;
                break;
            default:
                backgroundId = R.drawable.dgreen;


        }
        findViewById(R.id.main).setBackgroundResource(backgroundId);
    }


    @Override
    protected void onResume() {
        super.onResume();
        applyBackground(preferencesBmi.getInt(BACKGROUND_KEY, 0));
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applyBackground(preferencesBmi.getInt(BACKGROUND_KEY, 0));
    }
}
