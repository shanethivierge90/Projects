package Hangman2;

import java.util.Scanner;

import java.util.Arrays;

public class Hangman2 {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		
		// General note: Each string is changed to an array and might be changed back to a string for display purposes.

		//Simple introduction like in the instructions.
		String welcome = "-------------------\nWELCOME TO HANGMAN2\n-------------------\n";
		// \n will add a space each time it appears if it is an array or not.
		char[] arrayWelcome = welcome.toCharArray();
		System.out.println(arrayWelcome);
		String turnAround = "OK Guessing Player ... turn around, while your friend enters the word to guess!";
	    char[] arrayTurnAround = turnAround.toCharArray();
		System.out.println(arrayTurnAround);
	
	    // This section will allow the player to enter a word.
		String enterWord = "Enter your word (up to 10 letters only, not case sensitive): ";
        char[] arrayEnterWord = enterWord.toCharArray();
        System.out.print(arrayEnterWord);
        String hangmanWord = input.next().toLowerCase();
        char[] arrayHangmanWord = hangmanWord.toCharArray();
	
        // This will turn the word into an integer.
        int newHangmanWord = hangmanWord.length();			

		//This will add 20 spaces.
		String twentySpaces = "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";	
        char[] arrayTwentySpaces = twentySpaces.toCharArray();
		System.out.print(arrayTwentySpaces);	
		
		// An array for spaces when I need a single space.
        String space = "\n";
        char[] arraySpace = space.toCharArray();
				
		//The amount of guesses to subtract by each time.
		int guesses = 10;
       
		//This will change the word into "*" regardless of how long the word is.
		char [] arrayAsterisk = new char [newHangmanWord];
		for (int i = 0; i < 10; i++ ) {
			Arrays.fill(arrayAsterisk, '*');
		}
		
		// The list of letters.
		String letters = "abcdefghijklmnopqrstuvwxyz";
        char[] arrayLetters = letters.toCharArray();
		
		// This whole loop will run as long as there is more than zero guesses.
		// Keeps track of the guesses.
        while (guesses > 0) {
			// I used the Arrays.toString in order for the output not to look like a weird code.
        	// I used multiple replace() functions to remove the space, comma and square brackets for the output. 
			System.out.print(Arrays.toString(arrayAsterisk).replace(" ", "").replace(",", "").replace("[", "").replace("]", "")); 
			
			// I broke the array down to multiple parts for simplicity. It also helped me organize it better.
			String guessTrackerPartOne = " is the current word to date. ";
			char[] arrayGuessTrackerPartOne = guessTrackerPartOne.toCharArray();
			System.out.print(arrayGuessTrackerPartOne);
			System.out.print(guesses);
			
			String guessTrackerPartTwo = " guess(es) left. ";
			char[] arrayGuesstrackerPartTwo = guessTrackerPartTwo.toCharArray();
			System.out.println(arrayGuesstrackerPartTwo);
		
			// Lets user input between yes or no.
			// The user loses a guess if they do not select yes or no.
			String wantToSolve = "Want to solve the puzzle? Enter \"Y\" to solve the puzzle, or \"N\" to guess a character: ";
			char[] arrayWantToSolve = wantToSolve.toCharArray();
			System.out.print(arrayWantToSolve);
			String yesNo = input.next();
	        char[] arrayYesNo = yesNo.toCharArray();
	
				// If the user chooses yes in lower case or upper case.
				if (arrayYesNo[0] == 'Y' || arrayYesNo[0] =='y'){
					// The user guesses the word.
					String theWordIs = "What do you think the word is? ";
					char[] arrayTheWordIs = theWordIs.toCharArray();
					System.out.print(arrayTheWordIs);
					String guessedWord = input.next().toLowerCase();
					char[] arrayGuessedWord = guessedWord.toCharArray();				
					
					// Arrays.equals checks if the user gets the word correct.
					if (Arrays.equals(arrayGuessedWord, arrayHangmanWord)) {
						// I used two lines for the following code. Otherwise, the line would be too long.
						// I broke the array down to multiple parts for simplicity. It also helped me organize it better.
						String correctGuessPartOne = "\n------------------------------------------------------------------------------------------------------\n"
								+ "Congratulations!!!";
						char[] arrayCorrectGuessPartOne = correctGuessPartOne.toCharArray();				
						System.out.println(arrayCorrectGuessPartOne);
						
						String correctGuessPartTwo ="You guessed the mystery word \"";	
						char[] arrayCorrectGuessPartTwo = correctGuessPartTwo.toCharArray();				
						System.out.print(arrayCorrectGuessPartTwo);
						System.out.print(arrayHangmanWord);
						
						String correctGuessPartThree = "\" in "; 		
						char[] arrayCorrectGuessPartThree = correctGuessPartThree.toCharArray();				
						System.out.print(arrayCorrectGuessPartThree);
						System.out.print(guesses-1); //Subtracts one guess.
						
						// I made the following code two lines, otherwise the line would be too long.
						String correctGuessPartFour = " guess(es)!\nGoodbye..."
								+ "\n------------------------------------------------------------------------------------------------------";
						char[] arrayCorrectGuessPartFour = correctGuessPartFour.toCharArray();				
						System.out.print(arrayCorrectGuessPartFour);
						break; // Breaks the loop.
					
					// If the user does not get the word correct.
					} else {
						String incorrect = "-->Incorrect...You lose a guess\n";
						char[] arrayIncorrect = incorrect.toCharArray();				
						System.out.println(arrayIncorrect);
						guesses--; //Will subtract the guesses each time this appears.
					}	

				// If the user chooses no in lower case or upper case.	
				} else if (arrayYesNo[0] == 'N' || arrayYesNo[0] == 'n'){
					// Shows list of letters and then the user can input a letter..
					String lettersToTry = "Letters to try: ";
					char[] arrayLettersToTry = lettersToTry.toCharArray();				
					System.out.print(arrayLettersToTry);
					System.out.println(arrayLetters);					
					
					// Made this multiple lines. Otherwise, the line would be too long.
					String whichLetters = "\nYou will lose a guess for choosing more than one letter or using a letter already guessed! "
							+ "\nWhich letter should I check for? ";
                    char[] arrayWhichLetters = whichLetters.toCharArray();
                    System.out.print(arrayWhichLetters);
                    
                    // Player can guess letter and that letter will be changed to lower case if it is uppercase.
					String guessedLetter = input.next().toLowerCase();
                    char[] arrayGuessedLetter = guessedLetter.toCharArray();
                    System.out.println(arraySpace);
					
					// If user chooses a number or a special character, it will not work and they lose a guess.
					if (arrayGuessedLetter[0] == '1' || arrayGuessedLetter[0] == '2' || arrayGuessedLetter[0] == '3' || arrayGuessedLetter[0] == '4' 
							|| arrayGuessedLetter[0] == '5' || arrayGuessedLetter[0] == '6' || arrayGuessedLetter[0] == '7' || arrayGuessedLetter[0] == '8' 
							|| arrayGuessedLetter[0] == '9' || arrayGuessedLetter[0] == '!' || arrayGuessedLetter[0] == '@' || arrayGuessedLetter[0] == '#' 
							|| arrayGuessedLetter[0] == '$' || arrayGuessedLetter[0] == '%' || arrayGuessedLetter[0] == '^' || arrayGuessedLetter[0] == '&' 
							|| arrayGuessedLetter[0] == '*' || arrayGuessedLetter[0] == '(' || arrayGuessedLetter[0] == ')' || arrayGuessedLetter[0] == '-' 
							|| arrayGuessedLetter[0] == '_' || arrayGuessedLetter[0] == '=' || arrayGuessedLetter[0] == '+' || arrayGuessedLetter[0] == '{' 
							|| arrayGuessedLetter[0] == '[' || arrayGuessedLetter[0] == '}' || arrayGuessedLetter[0] == ']' || arrayGuessedLetter[0] == '|' 
							|| arrayGuessedLetter[0] == ';' || arrayGuessedLetter[0] == ':' || arrayGuessedLetter[0] == '"' || arrayGuessedLetter[0] == '<' 
							|| arrayGuessedLetter[0] == '>' || arrayGuessedLetter[0] == ',' || arrayGuessedLetter[0] == '.' || arrayGuessedLetter[0] == '/' 
							|| arrayGuessedLetter[0] == '?') {
						// I used two lines for the following code. Otherwise, the line would be too long.
						String notAValidRequest = "-->Not a valid request - not a letter or already guessed.\n"
								+ "-->You know what...for that you are losing a guess!\n"; //Just having a little fun here.
	                    char[] arrayNotAValidRequest = notAValidRequest.toCharArray();
	                    System.out.println(arrayNotAValidRequest);
						guesses--;
					
					// If the character the user selects is more than one character long.
					} if (arrayGuessedLetter.length != 1) {
						String tooManyLetters = "-->There are too many letters! You lose a guess!";
	                    char[] arrayTooManyLetters = tooManyLetters.toCharArray();
	                    System.out.println(arrayTooManyLetters);
	                    System.out.println(arraySpace);
						guesses--;
					
					} else {
	                    	// For loop to change the "*" into a letter.
		                    char[] arrayNewCurrentWord = new char[hangmanWord.length()];
		                    for (int ii = 0; ii < arrayHangmanWord.length; ii++) 
		                        if (hangmanWord.charAt(ii) == arrayGuessedLetter[0] ) {
		                        	arrayNewCurrentWord[ii] += arrayGuessedLetter[0];
		                        } else {
		                            arrayNewCurrentWord[ii] += arrayAsterisk[ii];
		                        }
		                   // Will return the arrayNewCurrentWord back to the arrayAsterisk variable.
		                    arrayAsterisk = arrayNewCurrentWord;
		                    guesses--;
					}	
								
				// Final else statement in the loop.
				} else {
					System.out.println(arraySpace);
					guesses--;
					continue;
				}
					
				// If there are no more guesses, it is game over for the user.						
				if (guesses <= 0) {
					String noMoreGuessesPartOne = "---------------------------------------\nSorry, you did not guess the mystery word \"";
                    char[] arrayNoMoreGuessesPartOne = noMoreGuessesPartOne.toCharArray();
                    System.out.print(arrayNoMoreGuessesPartOne);
                    System.out.print(hangmanWord); 
                    String noMoreGuessesPartTwo = "\"\nGoodbye....\n---------------------------------------";
                    char[] arrayNoMoreGuessesPartTwo = noMoreGuessesPartTwo.toCharArray();
                    System.out.print(arrayNoMoreGuessesPartTwo);
                    break;
				}
		
				// If the user finds each letter in the word before the amount of guesses run out.
			    // ALso broken down to multiple parts to make it easy to follow.
				if (Arrays.equals(arrayAsterisk, arrayHangmanWord)) {
					String winnerPartOne = "-------------------------------\nCongradulations!\nYou guessed the mystery word \"";  
                    char[] arrayWinnerPartOne = winnerPartOne.toCharArray();
                    System.out.print(arrayWinnerPartOne);
                   
                    String winnerPartTwo = "\" in "; 
                    char[] arrayWinnerPartTwo = winnerPartTwo.toCharArray();
                    System.out.print(arrayHangmanWord);
                    System.out.print(arrayWinnerPartTwo);
                    System.out.print(guesses);
                    
                    String winnerPartThree = " guess(es)\nGoodbye....\n-------------------------------";
                    char[] arrayWinnerPartThree = winnerPartThree.toCharArray();
					System.out.print(arrayWinnerPartThree);
					break;
			}       			
		}			
	}	
}