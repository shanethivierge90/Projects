/**
 * 
 */
/**
 * 
 */
module Hnagman2 {
}