// Package will help organize the class.

package CCCS300_A1_Q2;


// We cannot input anything in the terminal without this.

import java.util.Scanner;


// The class.

public class CCCS300_A1_Q2 {
	
	
	// This is the main function.
	
	public static void main(String[] args) {
		
		
		// This is the scanner object for the input in the terminal.

		Scanner input = new Scanner(System.in);
		
		
		//Simple introduction per the instructions.
		
		System.out.println("Welcome to the Depreciation calculator!");
		
		
		// This will let us input the values.
		
		System.out.print("Enter values (Purchase price, Salvage value, and Years): ");
		
		int purchaseValue = input.nextInt();
		
		int salvageValue = input.nextInt();
		
		int yearsValue = input.nextInt();
		
		
		/* Equation: D = (P - S) / Y. This will give the Yearly Depreciation.
		
		 Double will make it a real number. This can be applied everywhere (double) is shown. */
		
		double yearlyDepreciation = (double) ((purchaseValue - salvageValue) / yearsValue);
		
		
		// The Math.round() will round it properly to one decimal.
		
		double newYearlyDepreciation = Math.round(yearlyDepreciation * 10) / 10.0; 
		
		
		// Equation: Yearly Depreciation % = (newYearlyDepreciation / purchaseValue) * 100.
		
		double yearlyDepreciationPercent = (double) (newYearlyDepreciation / purchaseValue) * 100;
		
		
		// The Math.round() will also round it properly to one decimal.
		
		double newYearlyDepreciationPercent = Math.round(yearlyDepreciationPercent * 10.0) / 10.0;
		
		
		/* This section will now show "number of years for salvage value to be 10% of purchase price."
		 
		We will use this form of the equation: Y = (P - S) / D.
		
		First, we need to calculate the new salvage value, which is 10% of the purchase price. */
		
		double newSalvageValue = (double) (purchaseValue * 0.1); // The 0.1 represents 10%.
		
		double yearsForSalvageValue = (double) ((purchaseValue - newSalvageValue) / yearlyDepreciation);
		
		
		// The Math.round()  will round the years properly to one decimal for the new salvage value.
		
		double newYearsForSalvageValue = Math.round(yearsForSalvageValue * 10) / 10.0;
		
		
		// This section is for the output of the results.
		
		System.out.println("Yearly depreciation = " + newYearlyDepreciation + ".");
		
		System.out.println("Yearly depreciation = " + newYearlyDepreciationPercent + ".");
		
		System.out.println("Number of years for salvage value to be 10% of purchase price = " + newYearsForSalvageValue + " years.");

	}

}