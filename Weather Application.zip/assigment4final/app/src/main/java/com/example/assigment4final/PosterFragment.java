package com.example.assigment4final;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class PosterFragment extends Fragment {

    private static final String ARG_MOVIE = "movie";
    private ImageView imageView;

    public static PosterFragment newInstance(String movie) {
        PosterFragment fragment = new PosterFragment();
        Bundle args = new Bundle();
        args.putString(ARG_MOVIE, movie);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_poster, container, false);
        imageView = view.findViewById(R.id.poster_image);
        if (getArguments() != null) {
            String movie = getArguments().getString(ARG_MOVIE);
            updateImage(movie);
        }
        return view;
    }

    public void updateImage(String movie) {
        if (imageView != null) {
            imageView.setImageResource(getPosterImage(movie));
        }
    }

    private int getPosterImage(String movie) {
        switch (movie) {
            case "The Batman":
                return R.drawable.batman;
            case "Top Gun":
                return R.drawable.tgun;
            case "The Beekeeper":
                return R.drawable.bkeep;
            case "Looper":
                return R.drawable.looop;
            case "Don't Worry Darling":
                return R.drawable.dwdarling;
            case "Arrival":
                return R.drawable.arrival;
            case "Avatar: The Way of Water":
                return R.drawable.avatartop;
            case "Star Wars":
                return R.drawable.swars;
            case "Me, Myself & Irene":
                return R.drawable.mmandi;
            case "Step Brothers":
                return R.drawable.sbrothers;
            case "The Big Lebowski":
                return R.drawable.bigl;
            case "Free Guy":
                return R.drawable.freeguy;
            default:
                return R.drawable.mmandi;
        }
    }
}
