package com.example.assigment4final;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class BlankFragment extends Fragment {

    private static final String ARG_GENRE = "genre";

    public static BlankFragment newInstance(String genre) {
        BlankFragment fragment = new BlankFragment();
        Bundle args = new Bundle();
        args.putString(ARG_GENRE, genre);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            String genre = getArguments().getString(ARG_GENRE);
            loadMoviesListFragment(genre);
        }
    }

    private void loadMoviesListFragment(String genre) {
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        MoviesListFragment fragment = MoviesListFragment.newInstance(genre);
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }
}
