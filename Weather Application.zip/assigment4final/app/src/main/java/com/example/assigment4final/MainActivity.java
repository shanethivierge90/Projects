package com.example.assigment4final;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity implements MoviesListFragment.OnMovieSelectedListener {

    private Spinner genreSpinner;
    private ViewPager viewPager;
    private ViewPagerAdapter viewPagerAdapter;
    private TabLayout tabLayout;
    private String currentMovie = "Me, Myself & Irene"; // Default movie

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        genreSpinner = findViewById(R.id.genre_spinner);
        viewPager = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.tab_layout);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.genres, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genreSpinner.setAdapter(adapter);

        genreSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String genre = (String) parent.getItemAtPosition(position);
                loadMoviesListFragment(genre);
                setDefaultMovie(genre);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        if (savedInstanceState != null) {
            currentMovie = savedInstanceState.getString("currentMovie");
            int position = savedInstanceState.getInt("spinnerPosition", 0);
            genreSpinner.setSelection(position);
        } else {
            // Default beginging
            loadMoviesListFragment("Comedy");
        }

        // Initialize ViewPagerAdapter with the current movie
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), currentMovie);
        viewPager.setAdapter(viewPagerAdapter);

        // Link TabLayout with ViewPager
        tabLayout.setupWithViewPager(viewPager);
    }

    private void loadMoviesListFragment(String genre) {
        Fragment fragment = MoviesListFragment.newInstance(genre);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }

    @Override
    public void onMovieSelected(String movie) {
        currentMovie = movie;
        if (viewPagerAdapter == null) {
            viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), movie);
            viewPager.setAdapter(viewPagerAdapter);
        } else {
            viewPagerAdapter.updateMovie(movie);
        }
    }

    private void setDefaultMovie(String genre) {
        switch (genre) {
            case "Comedy":
                currentMovie = "Me, Myself & Irene";
                break;
            case "Action":
                currentMovie = "The Batman";
                break;
            case "Sci-Fi":
                currentMovie = "Don't Worry Darling";
                break;
            default:
                break;
        }

        if (viewPagerAdapter != null) {
            viewPagerAdapter.updateMovie(currentMovie);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("currentMovie", currentMovie);
        outState.putInt("spinnerPosition", genreSpinner.getSelectedItemPosition());
    }
}
