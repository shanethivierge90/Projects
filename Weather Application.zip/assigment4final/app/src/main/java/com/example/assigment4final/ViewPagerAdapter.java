package com.example.assigment4final;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class ViewPagerAdapter extends FragmentPagerAdapter {

    private String currentMovie;
    private PosterFragment posterFragment;
    private DescriptionFragment descriptionFragment;


    public ViewPagerAdapter(@NonNull FragmentManager fm, String movie) {
        super(fm);
        this.currentMovie = movie;
        this.posterFragment = PosterFragment.newInstance(currentMovie);
        this.descriptionFragment = DescriptionFragment.newInstance(currentMovie);

    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return posterFragment;
        } else {
            return descriptionFragment;
        }
    }

    @Override
    public int getCount() {
        return 2;
    }


    public void updateMovie(String movie) {
        this.currentMovie = movie;
        posterFragment.updateImage(movie); //keep
        descriptionFragment.updateDescription(movie); // keep
        notifyDataSetChanged();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "Poster";
            case 1:
                return "Description";
            default:
                return null;
        }

    }
}
