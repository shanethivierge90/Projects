package com.example.assigment4final;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

public class MoviesListFragment extends Fragment {

    private static final String ARG_GENRE = "genre";
    private String genre;
    private ListView moviesListView;
    private OnMovieSelectedListener callback;

    public interface OnMovieSelectedListener {
        void onMovieSelected(String movie);
    }

    public static MoviesListFragment newInstance(String genre) {
        MoviesListFragment fragment = new MoviesListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_GENRE, genre);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnMovieSelectedListener) {
            callback = (OnMovieSelectedListener) context;
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            genre = getArguments().getString(ARG_GENRE);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movies_list, container, false);
        moviesListView = view.findViewById(R.id.movies_list_view);

        setupMovieList();
        return view;
    }

    private void setupMovieList() {
        String[] movies;
        switch (genre) {
            case "Action":
                movies = new String[]{"The Batman", "Top Gun", "The Beekeeper", "Looper"};
                break;
            case "Sci-Fi":
                movies = new String[]{"Don't Worry Darling", "Arrival", "Avatar: The Way of Water", "Star Wars"};
                break;
            case "Comedy":
            default:
                movies = new String[]{"Me, Myself & Irene", "Step Brothers", "The Big Lebowski", "Free Guy"};
                break;
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(requireContext(), android.R.layout.simple_list_item_1, movies) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.black));
                textView.setTextSize(18);
                textView.setBackgroundResource(R.drawable.list_item_background);
                return view;
            }
        };

        moviesListView.setAdapter(adapter);
        moviesListView.setOnItemClickListener((parent, view, position, id) -> {
            for (int i = 0; i < parent.getChildCount(); i++) {
                parent.getChildAt(i).setBackgroundResource(R.drawable.list_item_background);
            }
            view.setBackgroundResource(R.drawable.list_item_selected_background);
            if (callback != null) {
                callback.onMovieSelected((String) parent.getItemAtPosition(position));
            }
        });
    }

    @Override
    public void onDetach() {
        super.onDetach();
        callback = null;
    }
}
