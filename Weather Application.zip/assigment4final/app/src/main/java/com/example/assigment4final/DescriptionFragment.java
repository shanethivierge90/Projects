package com.example.assigment4final;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class DescriptionFragment extends Fragment {

    private static final String ARG_MOVIE = "movie";
    private TextView descriptionTextView;
    private TextView yearTextView;
    private TextView starsTextView;

    public static DescriptionFragment newInstance(String movie) {
        DescriptionFragment fragment = new DescriptionFragment();
        Bundle args = new Bundle();
        args.putString(ARG_MOVIE, movie);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_description, container, false);
        descriptionTextView = view.findViewById(R.id.description_text);
        yearTextView = view.findViewById(R.id.year_text);
        starsTextView = view.findViewById(R.id.stars_text);

        if (getArguments() != null) {
            String movie = getArguments().getString(ARG_MOVIE);
            setDescription(movie);
        }
        return view;
    }

    public void updateDescription(String movie) {
        if (descriptionTextView != null && yearTextView != null && starsTextView != null) {
            setDescription(movie);
        }
    }

    //Descriptions
    private void setDescription(String movie) {
        String description = "";
        String year = "";
        String stars = "";

        switch (movie) {
            case "The Batman":
                description = "Batman returns to stop The Riddler.";
                year = "Matt Reeves";
                stars = "Robert Pattinson, Zoë Kravitz";
                break;
            case "Top Gun":
                description = "Pilots competing with each other to see who is the best.";
                year = "Tony Scott";
                stars = "Tom Cruise, Val Kilmer";
                break;
            case "The Beekeeper":
                description = "A Beekeeper who is also a trained killer.";
                year = "David Ayer";
                stars = "Jason Statham, Emily Beecham";
                break;
            case "Looper":
                description = "A hitman must confront his older self from the future.";
                year = "Rian Johnson";
                stars = "Joseph Gordon-Levitt, Bruce Willis";
                break;
            case "Don't Worry Darling":
                description = "A young wife begins to question her perfect life.";
                year = "Olivia Wilde";
                stars = "Florence Pugh, Harry Styles";
                break;
            case "Arrival":
                description = "When aliens arrive, a linguist seeks to communicate with them.";
                year = "2016";
                stars = "Amy Adams, Jeremy Renner";
                break;
            case "Avatar: The Way of Water":
                description = "Pandora is back, this time with water.";
                year = "James Cameron";
                stars = "Sam Worthington, Zoe Saldana";
                break;
            case "Star Wars":
                description = "A story about galactic civil war.";
                year = "George Lucas";
                stars = "Mark Hamill, Harrison Ford";
                break;
            case "Me, Myself & Irene":
                description = "A Rhode Island state trooper with a split personality is in charge of protecting a young woman.";
                year = "Denis Villeneuve";
                stars = "Jim Carrey, Renée Zellweger";
                break;
            case "Step Brothers":
                description = "Two middle-aged men become stepbrothers, and they have to get along or get it on.";
                year = "Adam McKay";
                stars = "Will Ferrell, John C. Reilly";
                break;
            case "The Big Lebowski":
                description = "A bowler end's up in a kidnapping plot that has nothing to do with him.";
                year = "Joel Coen";
                stars = "Jeff Bridges, John Goodman";
                break;
            case "Free Guy":
                description = "A bank teller discovers he’s an NPC in a video game.";
                year = "Shawn Levy";
                stars = "Ryan Reynolds, Jodie Comer";
                break;

        }

        descriptionTextView.setText(description);
        yearTextView.setText(year);
        starsTextView.setText(stars);
    }
}
