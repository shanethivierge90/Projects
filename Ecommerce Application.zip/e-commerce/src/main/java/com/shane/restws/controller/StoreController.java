package com.shane.restws.controller;

import com.shane.restws.model.Items;
import com.shane.restws.repository.MySqlRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.management.AttributeNotFoundException;

@RestController
public class StoreController {

	@Autowired
	MySqlRepository mySqlRepository;

	@GetMapping("/get-all-items")
	public List<Items> getAllItems() {

		return mySqlRepository.findAll();

	}

	@GetMapping("get-items/{identity}")
	public Items getSingleItem(@PathVariable("identity") Integer id) {
		return mySqlRepository.findById(id).get();
	}

	@DeleteMapping("/remove/{id}")
	public boolean deleteRow(@PathVariable("id") Integer id) {
		if (!mySqlRepository.findById(id).equals(Optional.empty())) {
			mySqlRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@PutMapping("/update/{id}")
	public Items updateItems(@PathVariable("id") Integer id, @RequestBody Map<String, String> body) {

		Items current = mySqlRepository.findById(id).get();
		current.setProduct(body.get("product"));
		current.setPrice(Integer.parseInt(body.get("price")));
		current.setInventory_Quantity(Integer.parseInt(body.get("Inventory_Quantity")));
		mySqlRepository.save(current);
		return current;
	}

	@PostMapping("/add")
	public Items create(@RequestBody Map<String, String> body) {

		String product = body.get("product");
		Integer price = Integer.parseInt(body.get("price"));
		Integer inventory_Quantity = Integer.parseInt(body.get("Inventory_Quantity"));
		Items newItems = new Items(product, price, inventory_Quantity);

		return mySqlRepository.save(newItems);
	}

	private double calculateDiscountedPrice(double originalPrice) {
		// Apply 10% discount
		double discountedPrice = originalPrice * 0.9;
		return Double.parseDouble(String.format("%.2f", discountedPrice));
	}

	@GetMapping("/items")
	public ResponseEntity<List<Items>> getAllProducts(
			@RequestParam(required = false, defaultValue = "false") boolean applyDiscount) {
		List<Items> products = mySqlRepository.findAll();
		if (applyDiscount) {
			products.forEach(item -> {
				double discountedPrice = calculateDiscountedPrice(item.getPrice());
				item.setPrice(discountedPrice);
			});
		}
		return new ResponseEntity<>(products, HttpStatus.OK);
	}
	
}