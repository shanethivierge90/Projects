package com.shane.restws.repository;

import com.shane.restws.model.Items;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MySqlRepository extends JpaRepository<Items,Integer>{

}
