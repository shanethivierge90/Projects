package com.shane.restws.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

	@GetMapping("/")
	public String getHome() {
		return "home";
	}

	@GetMapping("/test")
	public String getTest() {
		return "Test";
	}

	@GetMapping("/person")
	public Item getItem() {

		Item p = new Item();
		p.setItemName("Gatorade");
		p.setItemPrice(4.99);
		return p;
	}

}

class Item {
	private String name;

	public String getName() {
		return name;
	}

	public void setItemName(String string) {
		// TODO Auto-generated method stub

	}

	public void setItemPrice(double d) {
		// TODO Auto-generated method stub

	}
}
