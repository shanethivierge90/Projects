package com.shane.restws.model;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "products")
public class Items {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonPropertyOrder({"idItems", "product", "price", "inventory_Quantity"})
	private Integer id;

	private String product;
	private double price;
	private int inventory_Quantity;

	public Items() {

	}

	public Items(String product, double price, int inventory_Quantity) {
		this.product = product;
		this.price = price;
		this.inventory_Quantity = inventory_Quantity;
	}

	public Integer getIdItems() {
		return id;
	}

	public void setIdItems(Integer id) {
		this.id = id;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getinventory_Quantity() {
		return inventory_Quantity;
	}

	public void setInventory_Quantity(int inventory_Quantity) {
		this.inventory_Quantity = inventory_Quantity;

	}

}
