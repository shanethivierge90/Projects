/**
 * 
 */
package Hangmancc;

/**
 * 
 */
public class c {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
