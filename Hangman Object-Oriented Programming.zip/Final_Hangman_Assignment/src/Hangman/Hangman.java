package Hangman;

import java.util.Scanner;

// The public class.
public class Hangman {
	// Everything that is private.
	private static int gameNumber = 1;
	private String hangmanWord;
	private int newHangmanWord;
	private int guesses;
	private String guessedLetter;
	private String asterisk;
	private String letters;
	private String yesNo;
	private int gameID;
	
	// Everything that is public.
	public Hangman() {
		// The gameNumber, which is now the gameID.
		gameID = gameNumber;
		// Each game increasing by one
		gameNumber++;
		//The amount  of guesses to subtract by each time.
		guesses = 10;
		letters = "abcdefghijklmnopqrstuvwxyz";
	}

	// To start the game.
	public void initializeGame_collectWord(Scanner keyIn) {

		//Simple introduction like in the instructions.
		System.out.println("--------------------");
		System.out.println("WELCOME TO HANGMAN " + gameID);
		System.out.println("--------------------");
		System.out.println("\n"); //Will add a space each time this appears.
		System.out.println("OK Guessing Player ... turn around, while your friend enters the word to guess!");

		// This section will allow the player to enter a word.
		System.out.print("Enter your word (up to 10 letters only, not case sensitive: ");
		hangmanWord = keyIn.next().toLowerCase();
		
		// This will turn the word into an integer.
		newHangmanWord = hangmanWord.length();
		
		// To let the users know to switch players.
		System.out.print("Great! Now switch to the other player.");

		//This will add 20 spaces.
		System.out.println("\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" 
				+ "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n" + "\n");		
       
		//This will change the word into "*" regardless of how long the word is.
		asterisk = "*".repeat(newHangmanWord);
	}
	
	// Where the player and guess the word or a letter.
	public void play_a_guess(Scanner keyIn) {
		
		// This whole loop will run as long as there is more than zero guesses.
			// Keeps track of the guesses.
			System.out.println("GameID " + gameID + ": " + asterisk + " is the current word to date. " + guesses + " guess(es) left");
			// Lets user input between yes or no.
			System.out.print("GameID " + gameID + ": Want to solve the puzzle? Enter \"Y\" to solve the puzzle, or \"N\" to guess a character: ");
			yesNo = keyIn.next();
			
				// If the user chooses yes(y) in lower case or upper case.
				if (yesNo.equals("Y") || yesNo.equals("y")){
					// The user guesses the word.
					System.out.print("GameID " + gameID + ": What do you think the word is? ");
					String guessedWord = keyIn.next().toLowerCase();
					
					// If the user gets the word correct.
					if (guessedWord.equals(hangmanWord)) {
						System.out.println("---------------------------------------------------------------");
						System.out.println("GameID " + gameID + ": Congratulations!!!");
						System.out.println("GameID " + gameID + ": You guessed the mystery word \"" + hangmanWord + "\" in " + (guesses + 1) + " guess(es)!");
						System.out.println("\n");
						System.out.println("GameID " + gameID + ": Goodbye....");
						System.out.println("---------------------------------------------------------------");
					
					// If the user does not get the word correct.
					} else {
						System.out.println("GameID " + gameID + ": Incorrect...You lose a guess");
						System.out.println("\n");
						guesses--; //Will subtract the guesses each time this appears.
					}	
	
				// If the user chooses no(n) in lower case or upper case.	
				} else if (yesNo.equals("N") || yesNo.equals("n")){
					// Shows list of letters and then the user can input a letter..
					System.out.println("GameID " + gameID + ": Here are the letters you can choose from. Please choose one: " + letters + " ");
					System.out.println("\nGameID " + gameID + ": You will lose a guess for choosing more than one letter or using a letter already guessed!");
					System.out.print("GameID " + gameID + ": Which letter should I check for? ");
					String guessedLetter = keyIn.next().toLowerCase();
					System.out.println("\n");
					
					// If user chooses a number or a special character, it will not work and they lose a guess.
					// It also includes most special characters.
					if (guessedLetter.equals("1") || guessedLetter.equals("2")|| guessedLetter.equals("3") || guessedLetter.equals("4") || guessedLetter.equals("5") 
							|| guessedLetter.equals("6") || guessedLetter.equals("7") || guessedLetter.equals("8") || guessedLetter.equals("9") || guessedLetter.equals("!") 
							|| guessedLetter.equals("@") || guessedLetter.equals("#") || guessedLetter.equals("$") || guessedLetter.equals("%") || guessedLetter.equals("^") 
							|| guessedLetter.equals("&") || guessedLetter.equals("*") || guessedLetter.equals("(") || guessedLetter.equals(")") || guessedLetter.equals("-") 
							|| guessedLetter.equals("_") || guessedLetter.equals("=") || guessedLetter.equals("+") || guessedLetter.equals("{") || guessedLetter.equals("[") 
							|| guessedLetter.equals("}") || guessedLetter.equals("]") || guessedLetter.equals("|") || guessedLetter.equals(";") || guessedLetter.equals(":") 
							|| guessedLetter.equals("\"\"") || guessedLetter.equals("<") || guessedLetter.equals(">") || guessedLetter.equals(",") || guessedLetter.equals(".") 
							|| guessedLetter.equals("/") || guessedLetter.equals("?")) {
						System.out.println("--> GameID " + gameID + ": Sorry, no numbers allowed!");
						System.out.println("\n");
						guesses--;
										
					// If the user inputs more than one character and they will lose a guess.
					} else if (guessedLetter.length() != 1) {
						System.out.println("--> GameID " + gameID + ": Sorry, needs to be no more than one character long. Haven't you played Hangman before?");
						// Just trying to have fun here.
						System.out.println("--> GameID " + gameID + ": You know what...for that you are losing a guess!");
						System.out.println("\n");
						guesses--;
									
					} else {
							// Created a new variable that has nothing in it.
		                    String newCurrentWord = "";
		                    // For loop to change the '*" into a letter.
		                    for (int ii = 0; ii < hangmanWord.length(); ii++) 
		                        if (hangmanWord.charAt(ii) == guessedLetter.charAt(0) ) {
		                            newCurrentWord += guessedLetter;
		                        } else {
		                            newCurrentWord += asterisk.charAt(ii);
		                        }
		                    // Will return the newCurrentWord back to the asterisk variable.
		                    asterisk = newCurrentWord;
		                    guesses--;
					}
				
				// Final else statement in the loop.
				} else {
					guesses--;
				}
			}
	
	// To finish the game.
	public void playGame(Scanner keyIn) {
		
			// If there are no more guesses, it is game over for the user.						
			if (guesses <= 0) {
				System.out.println("---------------------------------------");
				System.out.println("GameID " + gameID + "Sorry, you did not guess the mystery word \"" + hangmanWord + "\"");
				System.out.println("\n");
				System.out.println("Goodbye....");
				System.out.println("---------------------------------------");
			}
		
			// If the user finds each letter in the word before the amount of guesses run out.
			if (asterisk.equals(hangmanWord)) {
				System.out.println("--------------------------------------------------");
				System.out.println("GameID " + gameID + ": Congradulations!");
				System.out.println("You guessed the mystery word \"" + hangmanWord + "\" in " + (1 + (10 - (guesses + 1))) + " guess(es)");
				System.out.println("\n");
				System.out.println("Goodbye....");
				System.out.println("--------------------------------------------------");
			}       			
		}			
	}	

/*

- This is the Driver class file I used to make sure my code works.
- While most of it is from the example given in the instructions, I made a few changes to it to make it match closer to the example given in the assignment.
- I did this to make the out look as close as the sample as possible.

package Hangman;

import java.util.Scanner;


public class Driver {

	public static void main(String[] args) {
			
		Scanner key = new Scanner(System.in);
		
		Hangman h1 = new Hangman();
		h1.initializeGame_collectWord(key);
		
		Hangman h2 = new Hangman();
		h2.initializeGame_collectWord(key);
		h2.play_a_guess(key);
		h2.play_a_guess(key);
		h2.play_a_guess(key);
		h2.play_a_guess(key);
		h2.play_a_guess(key);
		h2.play_a_guess(key);
		h2.playGame(key);
		
		Hangman h3 = new Hangman();
		h3.initializeGame_collectWord(key);
		h3.play_a_guess(key);

		Hangman h4 = new Hangman();
		h4.initializeGame_collectWord(key);
		h3.play_a_guess(key);
		h4.play_a_guess(key);
		h3.play_a_guess(key);
		h4.play_a_guess(key);
		h3.play_a_guess(key);
		h3.play_a_guess(key);
		h3.play_a_guess(key);
		h3.playGame(key);

		h4.play_a_guess(key);
		h4.play_a_guess(key);
		h4.play_a_guess(key);
		h4.play_a_guess(key);
		h4.play_a_guess(key);
		h4.playGame(key);
		
		h1.play_a_guess(key);
		h1.play_a_guess(key);
		h1.play_a_guess(key);
		h1.playGame(key);

		key.close();
		}
	}
*/