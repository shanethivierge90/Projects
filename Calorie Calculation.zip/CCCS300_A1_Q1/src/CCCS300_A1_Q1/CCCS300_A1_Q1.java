// Package will help organize the class.

package CCCS300_A1_Q1;


// The class.

public class CCCS300_A1_Q1 {
	
	
	// This is the main function.
	
	public static void main(String[] args) {
		
		
		/* Constants for METS.
		
		Double will make it a real number. This can be applied everywhere double is written. */
		
		final double RUNNING6MPH_METS = 10.00;
				
		final double BASKETBALL_METS = 8.00;
		
		final double SLEEPING_METS = 1.00;
		
		
		/* Weight in pounds. These are the input arguments: 150, 175 and 160.

	    We had to change the string to an int to make it a number. */
		
		int weightOfRunnerLb = Integer.parseInt(args[0]);
		
		int weightOfBPlayerLb = Integer.parseInt(args[1]);
		
		int weightOfSleeperLb = Integer.parseInt(args[2]);
		
	
		// Lb converted to kg for each.
		
		double weightOfRunnerKg = weightOfRunnerLb / 2.2; 
		
		double weightOfBPlayerKg = weightOfBPlayerLb / 2.2; 
		
		double weightOfSleeperKg  = weightOfSleeperLb / 2.2;
		
		
		// Calories (Cal) = Minutes (0.0175 × METS × Weight in kilograms).
		
		double runnerCalBurned = 30 * 0.0175 * RUNNING6MPH_METS * weightOfRunnerKg; // The 30 represents the minutes by the runner.
		
		double bPlayerCalBurned = 60 * 0.0175 * BASKETBALL_METS * weightOfBPlayerKg; // The 60 represents the minutes by the basketball player.
		
		double sleeperCalBurned = 360 * 0.0175 * SLEEPING_METS * weightOfSleeperKg; // The 360 (6 hours * 60 minutes) represents minutes by the sleeper. 

		
		/* Converting to two decimals with first multiplication than division.

		The (int) turns x, y and z into integers. 
		
		The (double) turn x1, y1 and z1 back into real numbers for the new variables. */
		
		double x = runnerCalBurned * 100;
		int x1 = (int)x;
		double newRunnerCalBurned = (double)x1 / 100.00;
		
		double y = bPlayerCalBurned * 100;
		int y1 = (int)y;
		double newBPlayerCalBurned = (double)y1 / 100.00;
		
		double z = sleeperCalBurned * 100;
		int z1 = (int)z;
		double newSleeperCalBurned = (double)z1 / 100.00;
		
		
		// Final results.
		
		System.out.println("Welcome to the calorie calculator!");
		
		System.out.println("A " + weightOfRunnerLb + "LB person burned an estimated " + newRunnerCalBurned + " calories by Running.");
		
		System.out.println("A " + weightOfBPlayerLb + "LB person burned an estimated " + newBPlayerCalBurned + " calories by playing Basketball.");
		
		System.out.println("A " + weightOfSleeperLb + "LB person burned an estimated " + newSleeperCalBurned + " calories by Sleeping.");
		 
	
	
	}
}